#فصل اول پایتون
#متغیرهای پایتون  . متغیرها نیاز به تعریف نوع خاصی ندارند و حتی می توانند پس از تنظیم نوع خود را تغییر دهند.

x = 5
y = "word"
print(x)
print(y)

#ریخته گری (casting)
#اگر میخواهی نوع داده یک متغیرها را مشخص کنی میتوانی با استفاده از تبدیل نوع casting انجام بدهیم

x = str(3)
y = int(3)
z = float(3)
print(x)
print(y)
print(z)

#با استفاده از تابع میتوانی نوع متغیرها داده شده ارو بدست type( )

x = 5 
y = "index"

print(type(x))
print(type(y))


#اختصاص چندین مقدار
#پایتون به شما این امکان را میدهد که در یک خط چندین تغییر مقدار دهند

x, y, z = "orange", "banana", "cherry"
print(x)
print(y)
print(z)

#یک مقدار برای چندین متغییر

x = y = z ="orange"
print(x)
print(y)
print(z)

#باز کردن یک مجموعه
fruits = ["apple", "banana", "cherry"]
x, y, z = fruits

print(x)
print(y)
print(z)


#متغییر های خروجی

#تابع پایتون اغلب برای خروجی دادن متغییر ها استفاده میشود print()

x = "python is awesome"
print(x)
 
#در این تابع چندین متغییر را که با کاما از هم جدا شده اند خروجی می دهید print()
x ="python"
y = "is"
z = "awesome"
print(x,y,z)
#همچنین میتوانید از + عمگر برای خروجی استفاده کرد 
x = "python"
y = " is"
z = " awesome"
print(x + y + z)
# + برای اعاداد ریاضی هم عمل میکند
x = 10
y = 5
print(x + y)
 #در تابع پرینت وقتی سعی میکنید یک رشته و یک عدد را با + عملگر ترکیب کنید خطا میدهد
x = 5
y = "john"
#print(x + y)

#بهترین را ه حل برای خروجی گرفتن از چندین متغییر  جدا کردن انها با کاما است 

x = 5
y = "john"
print(x, y)


#متغییر های سراسری


#متغییر هایی که خارج از یک تابع ایجاد میشوند به عنوان متغییرهای سراسری شناخته میشوند متغیر های سراسری میتواندد توسط همه چه در داخل توابع و چه در خارج از انها مورد استفاده قرار گیرند
  
x = "awesome"
def myfunc():
  print("python is" + x)
  myfunc()

#اگر متغییری با نام یکسان درون یک تابع ایجاد کنید این متغییر محلی خواهد بود و فقط درون تابع قابل استفاده است متغییر سراسری با نام یکسان همان طور که بوده سراسری با مقدار اصلی باقی می ماند 
  

x = "awesome"
def myfunc():
  x = "fantastic"
  print("python is" + x)
   myfunc():
   print("python is" + x )


#همچنین اگر میخواهید یک متغییر سراسری را درون یک تابع تغییر دهید از کلمه کلیدی global استفاده کنید

 x = "awesome"
 def myfunc():
 global x
 x = "fantastic"
 myfunc()
 print("Python is " + x)
 
 
 
  x = 'awesome'
 def myfunc():
 x = 'fantastic'
 myfunc()
 print('Python is ' + x)
 
 
 
#قصل دوم پایتون

# تنظیم نوع داده
  
  #در پایتون  نوع داده هنگام اختصاص داده یک مقدار یه یک متغییر تبدیل میشود مثال:


x = "hello world"
#display x:
print(x)
#display the data type of x:
print(type(x))


  x ="20"
  #display x:
  print(x)
    #display the data type of x:
    print(type(x))



 x = ["apple", "banana", "cherry"]
 #display x:
 print(x)
 #display the data type of x:
 print(type(x)) 




x = frozenset({"apple", "banana", "cherry"})
 #display x:
 print(x)
 #display the data type of x:
 print(type(x))
 
 
 # اگر میخواهید نوع داده را مشخص کنید میتوانید از توابع سازنده زیر استفاده کنید
 
 
  x = str("Hello World")
 #display x:
 print(x)
 #display the data type of x:
 print(type(x)) 
 
 
 x = int(20)
 #display x:
 print(x)
 #display the data type of x:
 print(type(x)) 
 
 
 x = list(("apple", "banana", "cherry"))
 #display x:
 print(x)
 #display the data type of x:
 print(type(x)) 
 
 
 x = bool(5)
 #display x:
 print(x)
 #display the data type of x:
 print(type(x)) 
 
 
 #اعداد پایتون 
 
 x = 1
 y = 2.8
 z = 1j
 print(type(x))
 print(type(y))
 print(type(z))
 
 
 
 
  x = 1
 y = 35656222554887711
 z = -3255522
 print(type(x))
 print(type(y))
 print(type(z))
 
 
x = 3+5j
 y = 5j
 z = -5j

 print(type(x))
 print(type(y))
 print(type(z))
 
 
  x = 1.10
 y = 1.0
 z = -35.59
 print(type(x))
 print(type(y))
 print(type(z))
 
 
 #تبدیل نوع -- casting
 
 
  #convert from int to float:
 x = float(1)
 #convert from float to int:
 y = int(2.8)
 #convert from int to complex:
 z = complex(1)
 print(x)
 print(y)
 print(z)
 print(type(x))
 print(type(y))
 print(type(z))
 
 
 # میتوانید از علامت  درون یک رشته استفاده کنید البته تا زمانی که با علامت نقل قول های اطراف(quotes) 
 
 
  print("It's alright")
 print("He is called 'Johnny' ")
 print('He is called "Johnny" ')
 
 
 #رشته های پایتون 
 
 #پیمایش با استفاده از حلقه از انجایی که رشته ها ارایه هستند میتوانیم با استفاده از یک حلقه کاراکترهای یک رشته را پیمایش کنیم
 
  for x in "banana":
 print(x) 
 
 #len()برای بدست اوردن یک رشته از استفاده میکنیم
 
 a = "Hello, World!"
 print(len(a))
 
 #Python - Slicing Strings
 
 #شما میتوانید با استفاده از سینتکس sliceطیفی از کاراکترها برگردانید
 # برای برگرداندن بخشی از رشته اندیس شروع و اندیس پایان را که باعلامت دو نقطه از هم جداشده اند 
 

  b = "Hello, World!"
 print(b[2:5])
 

  b = "Hello, World!"
 print(b[:5])
 
 
  b = "Hello, World!"
 print(b[2:])
 
 
 b = "Hello, World!"
 print(b[-5:-2])
 
 # String Concatenation   الحاق رشته 
 
  a = "Hello"
 b = "World"
 c = a + " " + b
 print(c)
 
  a = "Hello"
 b = "World"
 c = a + b
 print(c)
 
 #پایتون ـ‌قالب بندی ـ‌ رشته ها 
 
  age = 36
 #This will produce an error:
 txt = "My name is John, I am " + age
 print(txt) 
 
 
 age = 36
 txt = f"My name is John, I am {age}"
 print(txt)
 
 
 #قالب بندی رشته ها در پایتون 
 
 price = 59
 txt = f"The price is {price} dollars"
 print(txt)
 
 
 txt = f"The price is {20 * 59} dollars"
 print(txt)
 
 
  price = 59
 txt = f"The price is {price:.2f} dollars"
 print(txt)
 
 
  name = "Alice"
 age = 30
 greeting = f"Hello, I'm {name} and I'm {age} years old."
 print(greeting) 
 
 
  x = 10
 y = 20
 result = f"The sum of {x} and {y} is {x + y}."
 print(result) 
 
 
#Escape Character


 txt = 'It\'s alright.'
 print(txt) 
 
 txt = "Hello\tWorld!"
 print(txt) 
 
 txt = "This will insert one \\ (backslash)."
 print(txt) 
 
 
 #This example erases one character (backspace):
 txt = "Hello \bWorld!"
 print(txt) 
 
 
 txt = "Hello\nWorld!"
 print(txt) 
 
 
 txt = "Hello\rWorld!"
 print(txt)
 
 #بولین های پایتون 
 #مقدایر بولی یکی از دو مقدار زیر را نشان میدهند true یا false
 
  print(10 > 9)
 print(10 == 9)
 print(10 < 9)
 
 
  a = 200
 b = 33
 if b > a:
 print("b is greater than a")
 else:
 print("b is not greater than a")
 
 #عملگرهای حسابی پایتون 
 
  x = 5
 y = 3
 print(x + y)
 
  x = 12
 y = 3
 print(x / y)
 
  x = 15
 y = 2
 print(x // y)
 
 
  x = 5
 y = 3
 print(x - y)
 
 
  x = 5
 y = 3
 print(x * y)
 
  x = 2
 y = 5
 print(x ** y) #same as 2*2*2*2*2
 
 #عملگرهای انتساب پایتون 
 
  x = 5
 print(x)
 
  x = 5
 x += 3
 print(x)
 
 #عملگرهای مقایسه ای پایتون 
 
  x = 5
 y = 3
 print(x == y)
 
  x = 5
 y = 3
 print(x != y)
 
  x = 5
 y = 3
 print(x >= y)
 
 #عملگرهای منطقی پایتون 
 
  x = 5
 print(x > 3 and x < 10)
 
 
  x = 5
 print(x > 3 or x < 4)
 
 
 x = 5
 print(not(x > 3 and x < 10))
 
 #عملگرهای هویت پایتون 
 
  x = ["apple", "banana"]
 y = ["apple", "banana"]
 z = x
 print(x is z)
 # returns True because z is the same object as x
 print(x is y)
 # returns False because x is not the same object as y, even if they have the same content
 print(x == y)
 
 
  x = ["apple", "banana"]
 y = ["apple", "banana"]
 z = x
 print(x is not z)
 # returns False because z is the same object as x
 print(x is not y)
 #returns True because x is not the same object as y, even if they have the same content
 print(x != y)
 
 
 #عملگرهای عضویت پایتون 
 
  x = ["apple", "banana"]
 print("banana" in x)
 
 
  x = ["apple", "banana"]
 print("pineapple" not in x)
 
 
 #عملگرهای بیتی پایتون
 
  print(6 & 3)
  
  
   print(6 | 3)